// const production = '';
// const development = "https://somethingtodoadmin.azurewebsites.net/";
// const development = "https://std-backend.herokuapp.com/api/"
const development = "https://walrus-app-xqntt.ondigitalocean.app/"
// export const baseUrl = process.env === 'development' ? development : production;
export const baseUrl = development;
